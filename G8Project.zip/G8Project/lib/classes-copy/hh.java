import org.w3c.dom.*;
import java.io.*;
import java.util.*;

public class hh {
    public void aaa() {
        String[] pp_tag = {"", "" ,""};
        System.out.print(pp_tag[2]);
    }
}
