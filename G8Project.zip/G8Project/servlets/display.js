﻿// 取得所有的卡片元素
var cards = document.getElementsByClassName('card');

// 將每個卡片設定滑鼠進入及離開的事件處理函式
for (var i = 0; i < cards.length; i++) {
    cards[i].addEventListener('mouseenter', function () {
        // 滑鼠進入時，將該卡片的content元素旋轉
        this.querySelector('.content').style.transform = 'rotateY(180deg)';
    });

    cards[i].addEventListener('mouseleave', function () {
        // 滑鼠離開時，將該卡片的content元素還原
        this.querySelector('.content').style.transform = 'rotateY(0deg)';
    });
}
function deleteCard(card) {
    /*var cardId = card.getAttribute("id");
    alert("Deleting...." + cardId);
    //let cardId = "m022";
    cardId = "m022";
    alert("Deleting...." + cardId);
    // 建立一個新的 XMLHttpRequest 物件
    var xhr = new XMLHttpRequest(); */
    cardId = card.id;
    //alert("Deleting....", cardId);
    // 建立一個新的 XMLHttpRequest 物件
    var xhr = new XMLHttpRequest();

    // 設定要發送的請求方式和 URL
    xhr.open("POST", "http://localhost:8080/G8Project/deleteCard", true);

    // 設定要傳送的資料，這裡以表單形式傳遞卡片的 ID 值
    var formData = new FormData();
    formData.append("cardId", cardId);

    // 資料送出到伺服器
    xhr.send(formData);
    /*xhr.onload = function () {
        alert(this.response);
    };*/

    //delete
    card.remove();
}


// 資料的 ID 遞增計數器
let idCounter = 1;

function addFlex() {
    // 獲取 flex 容器元素
    const flexContainer = document.getElementById('flexContainer');

    // 創建新的 flex 元素
    const newFlex = document.createElement('div');
    newFlex.classList.add('glass'); // 修正了类名

    // 设置新的 flex 元素的 ID
    if (idCounter >= 100) newFlex.id = 'm' + idCounter++;
    else if (idCounter >= 10) newFlex.id = 'm0' + idCounter++;
    else newFlex.id = 'm00' + idCounter++;

    // 創建名字輸入框
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.placeholder = '名字';

    // 創建種類輸入框
    const typeInput = document.createElement('input');
    typeInput.type = 'text';
    typeInput.placeholder = '種類';

    // 創建產地輸入框
    const placeInput = document.createElement('input');
    placeInput.type = 'text';
    placeInput.placeholder = '產地';

    // 創建價格輸入框
    const priceInput = document.createElement('input');
    priceInput.type = 'text';
    priceInput.placeholder = '價格';

    // 將名字輸入框和價格輸入框添加到新的 flex 元素中
    newFlex.appendChild(document.createElement('h3')).textContent = '名字';
    newFlex.appendChild(nameInput);
    newFlex.appendChild(document.createElement('h3')).textContent = '種類';
    newFlex.appendChild(typeInput);
    newFlex.appendChild(document.createElement('h3')).textContent = '產地';
    newFlex.appendChild(placeInput);
    newFlex.appendChild(document.createElement('h3')).textContent = '價格';
    newFlex.appendChild(priceInput);

    // 將新的 flex 元素添加到 flex 容器中
    flexContainer.appendChild(newFlex);

    // 監聽名字輸入框和價格輸入框的變化
    nameInput.addEventListener('input', updateXML);
    typeInput.addEventListener('input', updateXML);
    placeInput.addEventListener('input', updateXML);
    priceInput.addEventListener('input', updateXML);
}

function updateXML(event) {
    // 獲取觸發事件的輸入框
    const inputElement = event.target;

    // 獲取輸入框所在的 flex 元素
    const flexElement = inputElement.closest('.glass');

    // 獲取 flex 元素的 ID
    const flexId = flexElement.id;

    // 獲取名字輸入框和價格輸入框的值
    const name = flexElement.querySelector('input[type="text"][placeholder="名字"]').value;
    const type = flexElement.querySelector('input[type="text"][placeholder="種類"]').value;
    const place = flexElement.querySelector('input[type="text"][placeholder="產地"]').value;
    const price = flexElement.querySelector('input[type="text"][placeholder="價格"]').value;

    // 建立要傳送到後端的資料物件
    const data = {
        flexId: flexId,
        name: name,
        type: type,
        place: place,
        price: price
    };
}