import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;
// Web
import javax.servlet.*; 
import javax.servlet.http.*;

public class Update extends HttpServlet{
    protected void service(HttpServletRequest req, HttpServletResponse res){
        System.out.println("update");
        try{
            req.setCharacterEncoding("UTF-8");
            res.setContentType("text/html;charset=UTF-8");
            //PrintWriter out = res.getWriter();
            update();            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void update(){
        try {
            System.out.println("In to update().");
            //load test.xml
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            System.out.println("XML File: \n" + xml_path_file);
            //check
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file); 
            
            Element root = doc.getDocumentElement() ;
            
            String targetId = "m003";
            String targetName = "金針菇";//把m003的金針菇價格40->2000
            String newPrice = "2000";
            NodeList mushrooms = root.getElementsByTagName("蕈菇");//將來也可以用XPATH
            if (mushrooms.getLength() != 0){
                Node target_node = mushrooms.item(0) ;
                Text new_node = doc.createTextNode(newPrice);
                Text old_node = (Text) target_node.getChildNodes().item(0);
                target_node.replaceChild(new_node, old_node);
            }
            
            //利用 Transformer物件 儲存檔案
            Savefile ss = new Savefile();
            ss.save(doc, xml_path_file);
            
            System.out.println("Update over");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }   
}
