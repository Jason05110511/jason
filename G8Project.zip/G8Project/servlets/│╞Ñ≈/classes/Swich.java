import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.io.*;
import java.util.*;
// Web
import javax.servlet.*; 
import javax.servlet.http.*;

public class Swich extends HttpServlet{
    /*//load file
    protected void service(HttpServletRequest req, HttpServletResponse res){
        System.out.println("ToSwich");
        Document doc;
        try{
            req.setCharacterEncoding("UTF-8");
            res.setContentType("text/html;charset=UTF-8");
            PrintWriter out = res.getWriter();
            
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            System.out.println(xml_path_file);
            //check
            MyDTDValidator dd = new MyDTDValidator();
            doc = dd.check(xml_path_file);
            
            System.out.println("XML File: " + xml_path_file);
            //to add
            aaa(doc);
            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void aaa(Document doc){
        Add add = new Add(doc, true,"m004","哈哈菇",new String[]{"value1", "value2", "value3"});
        add.create();
    }
    /*
    public void aaaaa(){
        ServletContext context = getServletContext();
        String xml_path_file = context.getRealPath("../../蕈菇查詢專案XML.xml");
        System.out.println(xml_path_file);
        //check
        MyDTDValidator dd = new MyDTDValidator();
        Document doc = dd.check(xml_path_file);
        Add add = new Add(doc, true, "m004", "哈哈菇", new String[]{"value1", "value2", "value3"});
        add.create();
    }*/
    /*public void ddd(Document doc){
        Delete dd = new Delete(doc, "m004", "哈哈菇");
        dd.delete();
    }
    /*
    public void init(ServletConfig config) throws ServletException {
    super.init(config);
    // 在这里进行初始化操作
    }*/
}
