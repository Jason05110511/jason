import org.xml.sax.*;
public  class YourErrorHandler implements ErrorHandler{

    public  void fatalError (SAXParseException e)  throws SAXException {
        System.out.println("My fatalError : " + e.getMessage());
    }
    
    public  void error (SAXParseException e)  throws SAXException {
        System.out.println("My Error : " + e.getMessage());
    }
    
    public  void warning (SAXParseException e)  throws SAXException {
        System.out.println("My Warning : " + e.getMessage());
    }
}
