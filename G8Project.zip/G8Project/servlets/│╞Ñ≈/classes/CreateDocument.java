import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*; 

public class CreateDocument{
    public void createNewDocument(String xml_path_file){
        try {
            System.out.println("In to CreateDocument().");
            DocumentBuilderFactory fac = DocumentBuilderFactory.newInstance();
            fac.setNamespaceAware(true); //設定處理Namespace
            fac.setValidating(true); // //設定剖析XML文件時,進行驗證
            DocumentBuilder builder = fac.newDocumentBuilder();
            DOMImplementation impl = builder.getDOMImplementation();
            DocumentType doctype = impl.createDocumentType("G8:蕈菇查詢",null,"G8Project.dtd");
            Document doc = impl.createDocument( "http://www.G8Project", "G8:蕈菇查詢", doctype); //會自行將根元素插入到文件實體節點的下面
            
            //xsl
            ProcessingInstruction styleSheet = doc.createProcessingInstruction("xml-stylesheet", "type=\"text/xsl\" href=\"W14XSL.xsl\"");
            doc.insertBefore(styleSheet, doc.getDocumentElement());
            //利用 Transformer物件 儲存檔案
            Savefile ss = new Savefile();
            ss.save(doc, xml_path_file);
            
            System.out.println("Create over");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }  
}
