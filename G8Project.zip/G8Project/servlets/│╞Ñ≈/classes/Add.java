import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;
import  java.util.*;
// Web
import javax.servlet.*; 
import javax.servlet.http.*;

import java.nio.file.*;
import java.net.URL;

public class Add extends HttpServlet{
    boolean CreateP_tag;
    String p_id, p_name;
    String[] pp_tag;
    public Add(){
        CreateP_tag = false;
        p_id = "";
        p_name = "";
        pp_tag = new String[]{"", "", ""};
    }
    public Add(boolean CreateP_tag, String p_id, String p_name){
        this.CreateP_tag = CreateP_tag;
        this.p_id = p_id;
        this.p_name = p_name;
        pp_tag = new String[]{"", "", ""};
    }
    //Add obj = new Add("tag", "id", "name", new String[]{"value1", "value2", "value3"});
    public Add(boolean CreateP_tag, String p_id, String p_name, String[] pp_tag){
        this.CreateP_tag = CreateP_tag;
        this.p_id = p_id;
        this.p_name = p_name;
        this.pp_tag = new String[3];
        this.pp_tag[0] = pp_tag[0];
        this.pp_tag[1] = pp_tag[1];
        this.pp_tag[2] = pp_tag[2];
    }
    /*RequestDispatcher dispatcher = req.getRequestDispatcher("/index.html");
        dispatcher.forward(req, res);
        */
    protected void service(HttpServletRequest req, HttpServletResponse res){
        System.out.println("ToAdd");
        try{
            req.setCharacterEncoding("UTF-8");
            res.setContentType("text/html;charset=UTF-8");
            
            
            CreateP_tag = true;
            p_id = "m004";
            p_name = "哈哈菇";
            pp_tag = new String[]{"value1", "value2", "value3"};
            //PrintWriter out = res.getWriter();
            create();            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void create(){
        System.out.println(CreateP_tag + " " + p_id + " " + p_name + " " + pp_tag[0] + " " + pp_tag[1] + " "+ pp_tag[2]);
        if(!CreateP_tag){
                //如果CreateP_ta為false就跳過
                System.out.println("Skipping create() due to missing CreateP_tag is false.");
                return;
            }
        try {
            System.out.println("In to create().");
            
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            System.out.println("XML File: \n" + xml_path_file);
            //check
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file);
            if(doc == null){
                //沒有根標籤所以建一個 
                CreateDocument c = new CreateDocument();
                c.createNewDocument(xml_path_file);
            }
            
            Element root = doc.getDocumentElement();
            //<蕈菇 G8:id="m001" name="秀珍菇">
            if(root!=null && CreateP_tag){
                Element p = doc.createElementNS("", "蕈菇");
                p.setAttributeNS("","G8:id", p_id);
                p.setAttributeNS("","name", p_name);
                //<種類>平菇</種類> <產地>中國</產地> <價格>30</價格>
                if(pp_tag[0]!=""){ 
                    Element pp1 = doc.createElementNS("", "種類");
                    //pp1.appendChild(doc.createTextNode("平菇")); // 設置種類元素的文本内容為"平菇"
                    pp1.appendChild(doc.createTextNode(pp_tag[0]));
                    p.appendChild(pp1);
                }
                if(pp_tag[1]!=""){
                    Element pp2 = doc.createElementNS("", "產地");
                    pp2.appendChild(doc.createTextNode(pp_tag[1]));
                    p.appendChild(pp2);
                }
                if(pp_tag[2]!=""){
                    Element pp3 = doc.createElementNS("", "價格");
                    pp3.appendChild(doc.createTextNode(pp_tag[2]));
                    p.appendChild(pp3);
                }
                root.appendChild (p) ;
            }
            //利用 Transformer物件 儲存檔案
            Savefile ss = new Savefile();
            ss.save(doc, xml_path_file);
            
            System.out.println("Add over");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }   
}
