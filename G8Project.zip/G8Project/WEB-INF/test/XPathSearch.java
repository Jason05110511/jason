import  org.apache.xpath.XPathAPI;
import  org.w3c.dom.traversal.*; //for NodeIterator
import  org.w3c.dom.*; //for NodeIterator
import  java.util.Scanner;

import javax.servlet.*; 
import javax.servlet.http.*;

import java.util.*;
import java.io.*;
import java.lang.Object.*;


public class XPathSearch  extends HttpServlet{
    protected void service(HttpServletRequest req, HttpServletResponse res){
        try{
            req.setCharacterEncoding("UTF-8");
            String id = (String)req.getParameter("inputbox");
            //String id = "m001";
            System.out.println(id);
            String result = xpathsearch(id);
            System.out.println(result);
            //if(result!=null){
            res.setContentType("text/html;charset=UTF-8");
            PrintWriter out = res.getWriter();
            
            BufferedReader input = new BufferedReader(new StringReader(result));
            BufferedWriter output = new BufferedWriter(out);
            int ch;
            while((ch = input.read()) != -1){ 
                output.write(ch);
            }
            
            input.close();
            output.close();
            out.close();
            //}
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    
    public String xpathsearch(String id){
        String xpath = "/G8:蕈菇查詢/蕈菇[@G8:id='"+id+"']/種類";
        System.out.println(xpath);
        try{
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            //System.out.println(xml_path_file);
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file);
            if (doc==null) {
                System.out.println("Document error! ");
                return null;
            }
            else{
                System.out.println("通過驗證!");
            }
            Element root = doc.getDocumentElement();
            NodeIterator nl = XPathAPI.selectNodeIterator(doc, xpath, root);
            Node n;
            if ((n = nl.nextNode())!= null) {
                String name =  n.getTextContent();
                return ("查詢到的蕈菇種類是: " + name);
            }
        }catch(Exception e){ 
            e.printStackTrace();
        }
        return "whyerror";
    }
}
