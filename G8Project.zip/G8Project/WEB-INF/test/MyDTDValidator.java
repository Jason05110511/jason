import javax.xml.parsers.* ;
import org.w3c.dom.*;
import java.io.* ;
public class MyDTDValidator{
    public Document check(String fn){
        try{
            //利用 DocumentBuilder物件 的parse方法
            System.out.println(fn);
            //1. 產生DocumentBuilderFactory物件
            DocumentBuilderFactory dfactory = DocumentBuilderFactory.newInstance();
            dfactory.setValidating(true); //啟動validating處理機制
            dfactory.setNamespaceAware(true); //啟動Namespace validating處理機制

            //2. 產生DocumentBuilder物件
            DocumentBuilder builder = dfactory.newDocumentBuilder();
            //自己的錯誤處理類別程式
            builder.setErrorHandler(new YourErrorHandler());
            //3. parse XML文件
            Document doc = builder.parse(new File(fn)); //掃描錯誤會丟出錯誤    
            return doc;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        } 
    }
}