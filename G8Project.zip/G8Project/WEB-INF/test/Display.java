import javax.xml.parsers.*;
import org.w3c.dom.*;
import java.io.*;
import java.util.*;
//為了儲存XML檔之用
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

// Web
import javax.servlet.*; 
import javax.servlet.http.*;

public  class Display extends HttpServlet{
    protected void service(HttpServletRequest req, HttpServletResponse res ){
        try{
            req.setCharacterEncoding("UTF-8");
        }catch(IOException e){
            e.printStackTrace();
        }
        ServletContext context = getServletContext();
        String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
        String xsl_path_file = context.getRealPath("W14XSL.xsl");
        
        test(xml_path_file, xsl_path_file, res);
    }

    public void test(String xmlpath, String xslpath, HttpServletResponse res) {
        try {
            res.setContentType("text/html;charset=UTF-8");
            //1. 載入XML文件      
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setNamespaceAware(true);
            factory.setValidating(true);
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new File (xmlpath) );

            //2. 將XML文件用XSL檔進行XML文件轉換
            TransformerFactory tranFactory = TransformerFactory.newInstance();
            StreamSource  xsl = new StreamSource(xslpath) ; 
            Transformer aTransformer = tranFactory.newTransformer(xsl); 
            Source src = new DOMSource(doc);
            PrintWriter out= res.getWriter();
            Result dest = new StreamResult(out);
            aTransformer.transform(src, dest);
        }
        catch ( Exception e) {
            System.out.println("I go error here!");
            e.printStackTrace();
        }     
    }

    
}
