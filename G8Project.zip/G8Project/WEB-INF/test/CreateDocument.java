import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*; 

public class CreateDocument{
    public void createNewDocument(){
        try {
            DocumentBuilderFactory fac = DocumentBuilderFactory.newInstance();
            fac.setNamespaceAware(true); //設定處理Namespace
            fac.setValidating(true); // //設定剖析XML文件時,進行驗證
            DocumentBuilder builder = fac.newDocumentBuilder();
            DOMImplementation impl = builder.getDOMImplementation();
            DocumentType doctype = impl.createDocumentType("G8:蕈菇查詢",null,"G8Project.dtd");
            Document doc = impl.createDocument( "http://www.G8Project", "G8:蕈菇查詢", doctype); //會自行將根元素插入到文件實體節點的下面

            //利用 Transformer物件 儲存檔案
            TransformerFactory tranFactory = TransformerFactory.newInstance(); 
            Transformer aTransformer = tranFactory.newTransformer(); 

            //準備進行存檔成為檔名 filename
            Source src = new DOMSource(doc);
            Result dest = new StreamResult(new FileOutputStream("../../蕈菇查詢OnlyXML.xml")); 
            //set indent and doctype
            aTransformer.setOutputProperty(OutputKeys.INDENT, "yes");//縮排

            DocumentType doctype2 = doc.getDoctype();
            if(doctype2 != null) {
                //aTransformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, doctype2.getPublicId());
                aTransformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, doctype2.getSystemId());
            }
            //呼叫transform分法, 進行存檔 
            aTransformer.transform(src, dest);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }  
}
