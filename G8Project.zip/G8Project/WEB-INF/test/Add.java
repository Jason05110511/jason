import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;
import  java.util.*;
// Web
import javax.servlet.*; 
import javax.servlet.http.*;

import java.nio.file.*;
import java.net.URL;

public class Add extends HttpServlet{
    boolean CreateP_tag;
    String p_id, p_name;
    String[] pp_tag;
    public Add(){
        CreateP_tag = false;
        p_id = "";
        p_name = "";
        pp_tag = new String[]{"", "", ""};
    }
    public Add(boolean CreateP_tag, String p_id, String p_name){
        this.CreateP_tag = CreateP_tag;
        this.p_id = p_id;
        this.p_name = p_name;
        pp_tag = new String[]{"", "", ""};
    }
    //Add obj = new Add("tag", "id", "name", new String[]{"value1", "value2", "value3"});
    public Add(boolean CreateP_tag, String p_id, String p_name, String[] pp_tag){
        this.CreateP_tag = CreateP_tag;
        this.p_id = p_id;
        this.p_name = p_name;
        this.pp_tag = new String[3];
        this.pp_tag[0] = pp_tag[0];
        this.pp_tag[1] = pp_tag[1];
        this.pp_tag[2] = pp_tag[2];
    }
    /*RequestDispatcher dispatcher = req.getRequestDispatcher("/index.html");
        dispatcher.forward(req, res);
        */
    protected void service(HttpServletRequest req, HttpServletResponse res){
        System.out.println("ToAdd");
        try{
            req.setCharacterEncoding("UTF-8");
            res.setContentType("text/html;charset=UTF-8");
            
            
            
            PrintWriter out = res.getWriter();
            
            
            System.out.println("XML File: " + xml_path_file);
            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void create(){
        System.out.println(CreateP_tag + " " + p_id + " " + p_name + " " + pp_tag[0] + " " + pp_tag[1] + " "+ pp_tag[2]);
        try {
            System.out.println("In to create().");
            DocumentBuilderFactory fac = DocumentBuilderFactory.newInstance();
            fac.setNamespaceAware(true); //設定處理Namespace
            fac.setValidating(true); // //設定剖析XML文件時,進行驗證
            
            //處理驗證期間的警告、錯誤和致命錯誤
            DocumentBuilder builder1 = fac.newDocumentBuilder();//
            builder1.setErrorHandler(new YourErrorHandler());;//
            
            
            //DocumentBuilder builder = fac.newDocumentBuilder();
            //Document doc = builder.parse("../../蕈菇查詢OnlyXML.xml");
            /*Path filePath = Paths.get("../../蕈菇查詢OnlyXML.xml");//
            String absolutePath = filePath.toAbsolutePath().toString();//
            Document doc = builder.parse(new URL("file:///" + absolutePath).openStream());//*/
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            System.out.println(xml_path_file);
            //check
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file);
            
        
      
            Element root = doc.getDocumentElement(); 
            //<蕈菇 G8:id="m001" name="秀珍菇">
            if(root!=null && CreateP_tag){
                Element p = doc.createElementNS("", "蕈菇");
                p.setAttributeNS("","G8:id", "m001");
                //p.setAttributeNS("","G8:id", p_id);
                p.setAttributeNS("","name", "秀珍菇");
                //p.setAttributeNS("","name", p_name);
                //<種類>平菇</種類> <產地>中國</產地> <價格>30</價格>
                if(pp_tag[0]!=""){ 
                    Element pp1 = doc.createElementNS("", "種類");
                    //pp1.appendChild(doc.createTextNode("平菇")); // 設置種類元素的文本内容為"平菇"
                    pp1.appendChild(doc.createTextNode(pp_tag[0]));
                    p.appendChild(pp1);
                }
                if(pp_tag[1]!=""){
                    Element pp2 = doc.createElementNS("", "產地");
                    pp2.appendChild(doc.createTextNode(pp_tag[1]));
                    p.appendChild(pp2);
                }
                if(pp_tag[2]!=""){
                    Element pp3 = doc.createElementNS("", "價格");
                    pp3.appendChild(doc.createTextNode(pp_tag[2]));
                    p.appendChild(pp3);
                }
                root.appendChild (p) ;
            }
        
            //利用 Transformer物件 儲存檔案
            TransformerFactory tranFactory = TransformerFactory.newInstance(); 
            Transformer aTransformer = tranFactory.newTransformer(); 

            //準備進行存檔成為檔名 filename
            Source src = new DOMSource(doc);
            Result dest = new StreamResult(new FileOutputStream("../../蕈菇查詢專案XML.xml")); 
            //set indent and doctype
            aTransformer.setOutputProperty(OutputKeys.INDENT, "yes");

            DocumentType doctype2 = doc.getDoctype();
            if(doctype2 != null) {
                //aTransformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, doctype2.getPublicId());
                aTransformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, doctype2.getSystemId());
            }
            //呼叫transform分法, 進行存檔 
            aTransformer.transform(src, dest);
            System.out.println("Add over");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }   
}
