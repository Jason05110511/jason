import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;

public class TestUpdate
{
  public void update() {
   try {
      //load test.xml
      DocumentBuilderFactory fac = DocumentBuilderFactory.newInstance();
      DocumentBuilder builder = fac.newDocumentBuilder();
      Document doc = builder.parse("test2.xml"); 
      Element root = doc.getDocumentElement() ;
      NodeList targets = root.getElementsByTagName("年") ; //將來也可以用XPATH
      if (targets.getLength() != 0) {
         Node target_node = targets.item( 0 ) ;
         Text new_node = doc.createTextNode("中華民國98年");
         Text old_node = (Text) target_node.getChildNodes().item( 0 ) ;
         target_node.replaceChild(new_node, old_node) ;
        }
      //利用 Transformer物件 儲存檔案
      TransformerFactory tranFactory = TransformerFactory.newInstance(); 
      Transformer aTransformer = tranFactory.newTransformer(); 
      Source src = new DOMSource(doc);
      Result dest = new StreamResult(new FileOutputStream("newtest2.xml")); 
      aTransformer.transform(src, dest);
   } catch (Exception e) {
         e.printStackTrace();
   }
  }   
}
