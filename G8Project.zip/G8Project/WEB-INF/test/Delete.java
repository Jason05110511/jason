import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;

public class Delete{
    Document doc;
    String targetId, targetName;
    public Delete( String targetId){
        this.targetId = targetId;
        targetName = "";
    }
    public Delete(Document doc, String targetId){
        this.doc = doc;
        this.targetId = targetId;
        targetName = "";
    }
    public Delete(Document doc, String targetId,String targetName){
        this.doc = doc;
        this.targetId = targetId;
        this.targetName = targetName;
    }
    public void delete(){
        try{
            System.out.println("In to delete.");
            //load test.xml
            //單機版
            DocumentBuilderFactory fac = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = fac.newDocumentBuilder();
            Document doc = builder.parse("../../G8ProjectwihtDTDNS.xml");
            /*ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");*/
            //System.out.println(xml_path_file);
            /*MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file);*/
            
            Element root = doc.getDocumentElement();
            /*
            String targetId = "m003";
            String targetName = "金針菇";*/ 
            //遍歷蕈菇元素，查找匹配的元素並刪除
            NodeList mushrooms = root.getElementsByTagName("蕈菇");
            for(int i=0; i<mushrooms.getLength(); i++){
                Element mushroom = (Element) mushrooms.item(i);
                String id = mushroom.getAttribute("G8:id");
                String name = mushroom.getAttribute("name");

                //檢查屬性和文本內容是否匹配，如果匹配則刪除蕈菇元素
                if (id.equals(targetId) || name.equals(targetName)) {
                    root.removeChild(mushroom);
                    break;
                }
            }/*
            NodeList targets = root.getElementsByTagName("年") ; //將來也可以用XPATH
            if (targets.getLength() != 0) {
             Node target_node = targets.item( 0 ) ;
             root.removeChild(target_node) ;
            }*/
            //利用 Transformer物件 儲存檔案
            TransformerFactory tranFactory = TransformerFactory.newInstance(); 
            Transformer aTransformer = tranFactory.newTransformer(); 
            Source src = new DOMSource(doc);
            Result dest = new StreamResult(new FileOutputStream("../../蕈菇查詢專案XML.xml"));
            aTransformer.setOutputProperty(OutputKeys.INDENT, "yes");//縮排
            aTransformer.transform(src, dest);    
        }catch(Exception e) {
            e.printStackTrace();
        }
    }   
}
