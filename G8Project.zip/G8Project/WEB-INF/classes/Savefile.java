import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;

public class Savefile{
    public void save(Document doc, String xml_path_file){
        try{
            System.out.println("In to save(Document doc, String xml_path_file).");
            //利用 Transformer物件 儲存檔案
            TransformerFactory tranFactory = TransformerFactory.newInstance(); 
            Transformer aTransformer = tranFactory.newTransformer(); 

            //準備進行存檔成為檔名 filename
            Source src = new DOMSource(doc);
            //Result dest = new StreamResult(new FileOutputStream("../../蕈菇查詢專案XML.xml")); 
            Result dest = new StreamResult(new FileOutputStream(xml_path_file));
            /*Result dest2 = new StreamResult(new FileOutputStream(xml_path_file+"../../蕈菇查詢OnlyXML.xml"));*/
            
            //set indent and doctype
            aTransformer.setOutputProperty(OutputKeys.INDENT, "yes");//縮排
            
            //set DTD
            DocumentType doctype2 = doc.getDoctype();
            if(doctype2 != null) {
                //aTransformer.setOutputProperty(OutputKeys.DOCTYPE_PUBLIC, doctype2.getPublicId());
                aTransformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, doctype2.getSystemId());
            }
            //呼叫transform分法, 進行存檔 
            aTransformer.transform(src, dest);
            System.out.println("Save over");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
