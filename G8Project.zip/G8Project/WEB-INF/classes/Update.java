import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.traversal.*;
import javax.xml.xpath.*;
// Web
import javax.servlet.*;
import javax.servlet.http.*;

public class Update extends HttpServlet {
    String id, name, new_type, new_place, new_price;
    protected void service(HttpServletRequest req, HttpServletResponse res) {
        System.out.println("update");
        try {
            req.setCharacterEncoding("UTF-8");
            res.setContentType("text/html;charset=UTF-8");
            id = (String) req.getParameter("up1");
            name = (String) req.getParameter("up2");
            new_type = (String) req.getParameter("up3");
            new_place = (String) req.getParameter("up4");
            new_price = (String) req.getParameter("up5");
            System.out.println("id: " + id + " name: " + name + " new_type: " + new_type + " new_place: " + new_place + " new_price: " + new_price);
            update(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update(String ID) {
        try {
            System.out.println("In to update().");
            // 加載 test.xml
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            System.out.println("XML File: \n" + xml_path_file);
            
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file);
            
            XPathSearch x = new XPathSearch();
            Node n = xpathgetnode(x.IDxpath(ID), doc);
            Node old_type = xpathgetnode(x.typeIDxpath(ID), doc);
            Node old_place = xpathgetnode(x.placeIDxpath(ID), doc);
            Node old_price = xpathgetnode(x.priceIDxpath(ID), doc);
            Element root = doc.getDocumentElement() ;
            if(n != null){
                if(name != ""){
                    Element targetElement = (Element) n;
                    targetElement.setAttribute("name", name);
                }
                else{System.out.println("000");}
    
                if (new_type != "") {
                    Text new_node = doc.createTextNode(new_type);
                    Text old_node = (Text) old_type.getChildNodes().item(0);
                    old_type.replaceChild(new_node, old_node); 
                    System.out.println("123");
                }
                if (new_place != "") {
                    Text new_node = doc.createTextNode(new_place);
                    Text old_node = (Text) old_place.getChildNodes().item(0);
                    old_place.replaceChild(new_node, old_node); 
                    System.out.println("456");
                }
                if (new_price != "") {
                    Text new_node = doc.createTextNode(new_price);
                    Text old_node = (Text) old_price.getChildNodes().item(0);
                    old_price.replaceChild(new_node, old_node); 
                    System.out.println("789");
                }
            }
            else{System.out.println("n == null");}

            // 利用 Transformer物件 儲存檔案
            Savefile ss = new Savefile();
            ss.save(doc, xml_path_file);

            System.out.println("Update over");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Node xpathgetnode(String xpath, Document doc) {
        System.out.println(xpath);
        try {
            if (doc==null) {
                System.out.println("Document error! ");
                return null;
            }
            Element root = doc.getDocumentElement();
            NodeIterator nl = XPathAPI.selectNodeIterator(doc, xpath, root);
            return nl.nextNode();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Errorrrrrrrr");
        return null;
    }
}
/*import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;
import  org.apache.xpath.XPathAPI;
import  org.w3c.dom.traversal.*;
import javax.xml.xpath.*;
// Web
import javax.servlet.*; 
import javax.servlet.http.*;

public class Update extends HttpServlet {
    String id, name, new_type, new_place, new_price;
    Document doc; // 用於存儲已解析的XML文件

    protected void service(HttpServletRequest req, HttpServletResponse res){
        System.out.println("update");
        try {
            req.setCharacterEncoding("UTF-8");
            res.setContentType("text/html;charset=UTF-8");
            id = (String) req.getParameter("up1");
            name = (String) req.getParameter("up2");
            new_type = (String) req.getParameter("up3");
            new_place = (String) req.getParameter("up4");
            new_price = (String) req.getParameter("up5");
            System.out.println("id: " + id + " name: " + name + " new_type: " + new_type + " new_place: " + new_place + " new_price: " + new_price);
            update(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void update(String ID){
        try {
            System.out.println("In to update().");
            // 加載 test.xml
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            System.out.println("XML File: \n" + xml_path_file);
            // 檢查
            MyDTDValidator dd = new MyDTDValidator();
            doc = dd.check(xml_path_file);

            XPathSearch x = new XPathSearch();
            Node n = xpathgetnode(x.IDxpath(ID));
            Node old_type = xpathgetnode(x.typeIDxpath(ID));
            Node old_place = xpathgetnode(x.placeIDxpath(ID));
            Node old_price = xpathgetnode(x.priceIDxpath(ID));

            if (n != null) {
                Text new_node = doc.createTextNode(new_type);
                Text old_node = (Text) old_type.getFirstChild();
                n.replaceChild(new_node, old_node);
            }
            if (n != null) {
                Text new_node = doc.createTextNode(new_place);
                Text old_node = (Text) old_place.getFirstChild();
                n.replaceChild(new_node, old_node);
            }
            if (n != null) {
                Text new_node = doc.createTextNode(new_price);
                Text old_node = (Text) old_price.getFirstChild();
                n.replaceChild(new_node, old_node);
            }

            // 利用 Transformer物件 儲存檔案
            Savefile ss = new Savefile();
            ss.save(doc, xml_path_file);

            System.out.println("Update over");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public Node xpathgetnode(String xpath){
        System.out.println(xpath);
        try {
            if (doc == null) {
                System.out.println("Document error! ");
                return null;
            }
            XPath xPath = XPathFactory.newInstance().newXPath();
            Node n = (Node) xPath.evaluate(xpath, doc, XPathConstants.NODE);
            return n;
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Errorrrrrrrr");
        return null;
    }
}
/*
   import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;
// Web
import javax.servlet.*; 
import javax.servlet.http.*;

public class Update extends HttpServlet{
    protected void service(HttpServletRequest req, HttpServletResponse res){
        System.out.println("update");
        try{
            req.setCharacterEncoding("UTF-8");
            res.setContentType("text/html;charset=UTF-8");
            //PrintWriter out = res.getWriter();
            update();            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void update(){
        try {
            System.out.println("In to update().");
            //load test.xml
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            System.out.println("XML File: \n" + xml_path_file);
            //check
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file); 
            
            Element root = doc.getDocumentElement() ;
            
            String targetId = "m003";
            String targetName = "金針菇";//把m003的金針菇價格40->2000
            String newPrice = "2000";
            NodeList mushrooms = root.getElementsByTagName("蕈菇");//將來也可以用XPATH
            if (mushrooms.getLength() != 0){
                Node target_node = mushrooms.item(0) ;
                Text new_node = doc.createTextNode(newPrice);
                Text old_node = (Text) target_node.getChildNodes().item(0);
                target_node.replaceChild(new_node, old_node);
            }
            
            //利用 Transformer物件 儲存檔案
            Savefile ss = new Savefile();
            ss.save(doc, xml_path_file);
            
            System.out.println("Update over");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }   
}

   */