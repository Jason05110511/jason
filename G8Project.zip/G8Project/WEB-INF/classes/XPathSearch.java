import  org.apache.xpath.XPathAPI;
import  org.w3c.dom.traversal.*; //for NodeIterator
import  org.w3c.dom.*; //for NodeIterator
import  java.util.Scanner;

import javax.servlet.*; 
import javax.servlet.http.*;

import java.util.*;
import java.io.*;
import java.lang.Object.*;


public class XPathSearch extends HttpServlet{
    protected void service(HttpServletRequest req, HttpServletResponse res) {
        try {
            req.setCharacterEncoding("UTF-8");
            String s = (String) req.getParameter("inputbox");
            String result;
            
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            System.out.println("XML File: \n" + xml_path_file);
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file);
            
            if(s.charAt(0) == 'm'){
                System.out.println("ID: " + s);
                result = IDNamesearch(IDxpath(s), xml_path_file);
                System.out.println(result);        
            }
            else{
                System.out.println("Name: " + s);
                result = IDNamesearch(Namexpath(s), xml_path_file);
                System.out.println(result);
            }
            
            
            res.setContentType("text/jsp;charset=UTF-8");
            req.setAttribute("result", result);
            
            // 將請求轉發gohome.jsp
            RequestDispatcher dispatcher = req.getRequestDispatcher("/servlets/gohome.jsp");
            dispatcher.forward(req, res);
        } catch (IOException | ServletException e) {
            e.printStackTrace();
        }
    }
    public String IDNamesearch(String xpath, String xml_path_file){
        System.out.println(xpath);
        try{
            /*ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");*/
            System.out.println("XML File: \n" + xml_path_file);
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file);
            if (doc==null) {
                System.out.println("Document error! ");
                return null;
            }
            else{
                System.out.println("通過驗證!");
            }
            
            Element root = doc.getDocumentElement();
            NodeIterator nl = XPathAPI.selectNodeIterator(doc, xpath, root);
            Node n;
            if ((n = nl.nextNode())!= null) {
                NamedNodeMap attributes = n.getAttributes();
                String name = attributes.getNamedItem("name").getNodeValue();
                String id = attributes.getNamedItem("G8:id").getNodeValue();
                return ("查詢到的蕈菇是: " + name + "<br>ID: " + id);
            }
        }catch(Exception e){ 
            e.printStackTrace();
        }
        return "Errorrrrrrrr";
    }
        public String IDxpath(String id){
        return "/G8:蕈菇查詢/蕈菇[@G8:id='"+id+"']";
    }
    public String typeIDxpath(String id){
        return "/G8:蕈菇查詢/蕈菇[@G8:id='"+id+"']/種類";
    }
    public String placeIDxpath(String id){
        return "/G8:蕈菇查詢/蕈菇[@G8:id='"+id+"']/產地";
    }
    public String priceIDxpath(String id){
        return "/G8:蕈菇查詢/蕈菇[@G8:id='"+id+"']/價格";
    }
    public String Namexpath(String name){
        return "/G8:蕈菇查詢/蕈菇[@name='"+name+"']";
    }
    public String typeNamexpath(String name){
        return "/G8:蕈菇查詢/蕈菇[@name='"+name+"']/種類";
    }
    public String placexpath(String name){
        return "/G8:蕈菇查詢/蕈菇[@name='"+name+"']/產地";
    }
    public String priceNamexpath(String name){
        return "/G8:蕈菇查詢/蕈菇[@G8:id='"+name+"']/價格";
    }
    /*public Node xpathgetnode(String xpath, String xml_path_file){
        System.out.println(xpath);
        try{
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file);
            if (doc==null) {
                System.out.println("Document error! ");
                return null;
            }
            else{
                System.out.println("通過驗證!");
            }
            Element root = doc.getDocumentElement();
            NodeIterator nl = XPathAPI.selectNodeIterator(doc, xpath, root);
            Node n = nl.nextNode();
            if (n != null) {
                return n;
            }
            
        }catch(Exception e){ 
            e.printStackTrace();
        }
        System.out.println("Errorrrrrrrr");
        return null;
    }*/

}

/*protected void service(HttpServletRequest req, HttpServletResponse res){
        try{
            req.setCharacterEncoding("UTF-8");
            String id = (String)req.getParameter("inputbox");
            //String id = "m001";
            System.out.println(id);
            String result = xpathsearch(id);
            System.out.println(result);
            
            res.setContentType("text/html;charset=UTF-8");
            PrintWriter out = res.getWriter();
            //讀取HTML檔
            ServletContext context = getServletContext();
            String HTML_path_file = context.getRealPath("servlets/gohome.html");
            System.out.println("HTML File: \n" + HTML_path_file);
            BufferedReader input = new BufferedReader(new FileReader(HTML_path_file));
            String line;
            while ((line = input.readLine()) != null) {
                out.println(line);
            }
            // 將結果和返回按鈕輸出到響應中
            //String backButton = "<button onclick=\"window.location.href='index.html'\">返回</button>";
            out.println(result);
            //out.println(backButton);
            
            input.close();
            out.close();
            /*
            //讀取HTML檔
            ServletContext context = getServletContext();
            String HTML_path_file = context.getRealPath("index.html");
            System.out.println("HTML File: \n" + HTML_path_file);
            BufferedReader input = new BufferedReader(new FileReader(HTML_path_file));
            String line;
            while ((line = input.readLine()) != null) {
                out.println(line);
            }
            input.close();
            out.close();*/
            /*
            BufferedReader input = new BufferedReader(new StringReader(result));
            BufferedWriter output = new BufferedWriter(out);
            int ch;
            while((ch = input.read()) != -1){ 
                output.write(ch);
            }
            input.close();
            out.close();
            */
       /* }catch(IOException e){
            e.printStackTrace();
        }
    }*/
