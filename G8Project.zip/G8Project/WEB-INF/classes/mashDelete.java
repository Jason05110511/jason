import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;
import javax.xml.xpath.*;
import  org.w3c.dom.traversal.*;
import org.xml.sax.InputSource;
import  org.apache.xpath.XPathAPI;
import  java.util.Scanner;
// Web
import javax.servlet.*; 
import javax.servlet.http.*; 

public class mashDelete extends HttpServlet{
    protected void service(HttpServletRequest req, HttpServletResponse res){
        System.out.println("Delete");
        try{
            req.setCharacterEncoding("UTF-8");
            res.setContentType("text/html;charset=UTF-8");
            String cardId = req.getParameter("cardId");
            System.out.println("cardId: " + cardId);
            String dt1 = (String) req.getParameter("inputbox");
            System.out.println("dt1: " + dt1);
            if (dt1!=null && !dt1.equals("")){
                System.out.println("dt1: " + dt1);
                delete(dt1);
            }
            if ( cardId!=null && !cardId.equals("")){
                System.out.println("cardId: " + cardId);
                delete(cardId);
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void delete(String ID){
        try{
            System.out.println("In to delete.");
            //load test.xml
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            System.out.println("XML File: \n" + xml_path_file);
            //check
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file);
            
            XPathSearch x = new XPathSearch();
            Element root = doc.getDocumentElement();
            NodeIterator nl = XPathAPI.selectNodeIterator(doc, x.IDxpath(ID), root);
            Node n;
            if((n = nl.nextNode())!= null) {
                Node parent = n.getParentNode();
                parent.removeChild(n);
                System.out.println("元素已成功刪除。");
            } else {
                System.out.println("找不到符合條件的元素。");
            }
            
            //利用 Transformer物件 儲存檔案
            Savefile ss = new Savefile();
            ss.save(doc, xml_path_file);
            
            System.out.println("Delete over");
        }catch(Exception e) {
            e.printStackTrace();
        }
    }   
}
/*
   import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import java.io.*;
// Web
import javax.servlet.*; 
import javax.servlet.http.*;

public class mashDelete extends HttpServlet{
    Document doc;
    String targetId, targetName;
    public mashDelete(String targetId){
        this.targetId = targetId;
        targetName = "";
    }
    public mashDelete(Document doc, String targetId){
        this.doc = doc;
        this.targetId = targetId;
        targetName = "";
    }
    public mashDelete(Document doc, String targetId,String targetName){
        this.doc = doc;
        this.targetId = targetId;
        this.targetName = targetName;
    }
    protected void service(HttpServletRequest req, HttpServletResponse res){
        System.out.println("Delete");
        try{
            req.setCharacterEncoding("UTF-8");
            res.setContentType("text/html;charset=UTF-8");
            //PrintWriter out = res.getWriter();
            delete();            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
    public void delete(){
        try{
            System.out.println("In to delete.");
            //load test.xml
            ServletContext context = getServletContext();
            String xml_path_file = context.getRealPath("蕈菇查詢專案XML.xml");
            System.out.println("XML File: \n" + xml_path_file);
            //check
            MyDTDValidator dd = new MyDTDValidator();
            Document doc = dd.check(xml_path_file);
            
            Element root = doc.getDocumentElement();
            
            String targetId = "m004";
            String targetName = "哈哈菇"; 
            //遍歷蕈菇元素，查找匹配的元素並刪除
            NodeList mushrooms = root.getElementsByTagName("蕈菇");
            for(int i=0; i<mushrooms.getLength(); i++){
                Element mushroom = (Element) mushrooms.item(i);
                String id = mushroom.getAttribute("G8:id");
                String name = mushroom.getAttribute("name");

                //檢查屬性和文本內容是否匹配，如果匹配則刪除蕈菇元素
                if (id.equals(targetId) || name.equals(targetName)){
                    root.removeChild(mushroom);
                    break;
                }
            }/*
            NodeList targets = root.getElementsByTagName("年") ; //將來也可以用XPATH
            if (targets.getLength() != 0) {
             Node target_node = targets.item( 0 ) ;
             root.removeChild(target_node) ;
            }*/
            //利用 Transformer物件 儲存檔案
/*            Savefile ss = new Savefile();
            ss.save(doc, xml_path_file);
            
            System.out.println("Delete over");
        }catch(Exception e) {
            e.printStackTrace();
        }
    }   
}

   */
